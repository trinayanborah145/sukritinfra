import { useEffect, useState } from "react";

const items = [
  {
    quote:
      "Moving into a Sukrit home felt like inheriting a piece of craftsmanship. Every detail was considered, every promise honoured.",
    name: "Anirban & Mitali Das",
    role: "Residents · Sukrit Heights, Guwahati",
  },
  {
    quote:
      "What stood out was the quiet professionalism — no theatrics, just a beautifully built home delivered exactly when they said it would be.",
    name: "Dr. Pranjal Borah",
    role: "Owner · Sukrit Greens, Jorhat",
  },
  {
    quote:
      "We've worked with several developers across India. Sukrit's attention to detail and integrity is genuinely rare.",
    name: "Rituparna Saikia",
    role: "Architect · Collaborator",
  },
];

export function Testimonials() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((p) => (p + 1) % items.length), 5500);
    return () => clearInterval(t);
  }, []);

  return (
    <section className="relative bg-[var(--charcoal)] py-[140px] px-6 lg:px-12 overflow-hidden grain">
      <span
        className="absolute top-10 left-10 font-display text-[var(--gold)] leading-none select-none"
        style={{ fontSize: "200px", opacity: 0.12 }}
      >
        “
      </span>

      <div className="max-w-[900px] mx-auto text-center relative z-10">
        <span className="eyebrow">Client Voices</span>

        <div className="mt-12 min-h-[280px] flex flex-col items-center justify-center">
          {items.map((it, idx) => (
            <div
              key={idx}
              className="absolute transition-opacity duration-1000"
              style={{ opacity: i === idx ? 1 : 0, pointerEvents: i === idx ? "auto" : "none" }}
            >
              <p className="font-display italic text-white text-[24px] lg:text-[32px] leading-[1.4] max-w-[760px]">
                {it.quote}
              </p>
              <div className="mt-10 text-[var(--gold)] text-[12px] uppercase tracking-[0.3em] font-medium">
                {it.name}
              </div>
              <div className="mt-2 text-white/50 text-[12px]">{it.role}</div>
            </div>
          ))}
        </div>

        <div className="mt-16 flex items-center justify-center gap-3">
          {items.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setI(idx)}
              className={`h-[6px] rounded-full transition-all ${
                i === idx ? "w-8 bg-[var(--gold)]" : "w-[6px] bg-white/30"
              }`}
              aria-label={`Show testimonial ${idx + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
