import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";

const links = [
  { label: "Our Legacy", href: "#legacy" },
  { label: "Projects", href: "#projects" },
  { label: "Vision", href: "#vision" },
  { label: "Contact", href: "#contact" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
          scrolled
            ? "bg-[rgba(248,245,240,0.92)] backdrop-blur-md border-b border-[var(--divider)]"
            : "bg-transparent border-b border-transparent"
        }`}
        style={{ animation: "fadeDown 0.8s ease 0.3s both" }}
      >
        <style>{`@keyframes fadeDown { from { opacity:0; transform:translateY(-20px);} to {opacity:1; transform:translateY(0);} }`}</style>
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12 h-[84px] flex items-center justify-between">
          <a
            href="#"
            className={`font-display uppercase text-[16px] lg:text-[18px] font-medium transition-colors ${
              scrolled ? "text-[var(--text-soft)]" : "text-white"
            }`}
            style={{ letterSpacing: "0.16em" }}
          >
            Sukrit Infrastructure
          </a>

          <nav className="hidden lg:flex items-center gap-10">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className={`text-[12px] font-medium uppercase transition-colors hover:text-[var(--gold)] ${
                  scrolled ? "text-[var(--text-soft)]" : "text-white/90"
                }`}
                style={{ letterSpacing: "0.18em" }}
              >
                {l.label}
              </a>
            ))}
            <a
              href="#contact"
              className={`btn-gold !py-3 !px-6 ${scrolled ? "" : "!text-white !border-white/70"}`}
            >
              Enquire Now
            </a>
          </nav>

          <button
            onClick={() => setOpen(true)}
            className={`lg:hidden ${scrolled ? "text-[var(--text-soft)]" : "text-white"}`}
            aria-label="Open menu"
          >
            <Menu size={24} />
          </button>
        </div>
      </header>

      {/* Mobile overlay */}
      <div
        className={`fixed inset-0 z-50 bg-[var(--charcoal)] transition-transform duration-700 ease-[cubic-bezier(0.77,0,0.175,1)] ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex justify-between items-center px-6 h-[84px]">
          <span className="font-display text-white uppercase text-[16px]" style={{ letterSpacing: "0.16em" }}>
            Sukrit
          </span>
          <button onClick={() => setOpen(false)} className="text-white" aria-label="Close menu">
            <X size={24} />
          </button>
        </div>
        <nav className="flex flex-col gap-8 px-8 pt-16">
          {links.map((l, i) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="font-display text-white text-4xl"
              style={{
                opacity: open ? 1 : 0,
                transform: open ? "translateY(0)" : "translateY(20px)",
                transition: `all 0.6s ease ${i * 0.1 + 0.2}s`,
              }}
            >
              {l.label}
            </a>
          ))}
        </nav>
      </div>
    </>
  );
}
