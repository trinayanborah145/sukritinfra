export function BrandStatement() {
  return (
    <section className="py-[120px] px-6 lg:px-12">
      <div className="max-w-[1440px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20">
        <div className="lg:col-span-7 reveal">
          <span className="eyebrow eyebrow-line">Our Foundation</span>
          <h2 className="font-display text-[36px] lg:text-[52px] mt-8 leading-[1.1] text-[var(--text-soft)] max-w-[640px]">
            With 25+ years of trusted real estate development, Sukrit Infrastructure has redefined quality living in Assam.
          </h2>
          <span className="divider-gold mt-10" />
          <p className="mt-8 text-[16px] leading-[1.8] text-[var(--text-muted)] max-w-[520px]">
            We take pride in our commitment to architectural excellence, timely delivery, and building communities that stand the test of time. Every project is a quiet promise to those who call our spaces home.
          </p>
          <a href="#legacy" className="story-link mt-10 inline-flex">
            Read More <span>→</span>
          </a>
        </div>

        <div className="lg:col-span-5 reveal">
          <div className="border border-[var(--divider)] p-10 lg:p-14 relative h-full flex flex-col justify-center">
            <div className="grid grid-cols-2 gap-6 relative">
              <div
                className="absolute left-1/2 top-0 bottom-0 w-px"
                style={{
                  background:
                    "linear-gradient(to bottom, transparent, var(--divider) 20%, var(--divider) 80%, transparent)",
                  transform: "rotate(15deg)",
                }}
              />
              <div className="text-center">
                <div className="font-display text-[64px] lg:text-[88px] font-light text-[var(--text-soft)] leading-none">
                  25<span className="text-[var(--gold)]">+</span>
                </div>
                <div className="mt-4 text-[11px] uppercase tracking-[0.25em] text-[var(--text-muted)] leading-relaxed">
                  Years of<br />Trusted Legacy
                </div>
              </div>
              <div className="text-center">
                <div className="font-display text-[64px] lg:text-[88px] font-light text-[var(--text-soft)] leading-none">
                  50<span className="text-[var(--gold)]">+</span>
                </div>
                <div className="mt-4 text-[11px] uppercase tracking-[0.25em] text-[var(--text-muted)] leading-relaxed">
                  Projects<br />Delivered
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
